package in.ineuron.service;

import org.springframework.beans.factory.annotation.Autowired;

import in.ineuron.model.Employee;
import in.ineuron.repo.IEmployeeRepo;

public class EmployeeServiceImpl implements IEmployeeService {
	@Autowired
	private IEmployeeRepo repo;
	@Override
	public String registerEmployee(Employee employee) {
		Integer id=repo.save(employee).getId();
		if(id==1)
			return "succesfully registered with given id :: "+id;
		else
			return "registration failed";
	}

}
