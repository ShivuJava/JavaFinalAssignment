package in.ineuron.repo;

import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;

import in.ineuron.model.Employee;
import net.bytebuddy.asm.Advice.OffsetMapping.Sort;

public interface IEmployeeRepo extends PagingAndSortingRepository<Employee, Integer>{

	

}
