package in.ineuron.service;

import java.awt.print.Pageable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort.Direction;

import in.ineuron.model.Employee;
import in.ineuron.repo.IEmployeeRepo;
import net.bytebuddy.asm.Advice.OffsetMapping.Sort;

public class EmployeeService implements IEmployeeService {
	
	@Autowired
	private IEmployeeRepo repo;
	
	@Override
	public List<Employee> getAllEmployeesBySorting(String order, String property) {
		Sort sort=Sort.by(((order=="asc")?Direction.ASC:Direction.DESC), property);
		return (List<Employee>) repo.findAll(sort);
		
	}

	@Override
	public Page<Employee> getAllEmployeesByPagination(Pageable pageable)
	{	
		return repo.findAll(pageable);
		}

}
