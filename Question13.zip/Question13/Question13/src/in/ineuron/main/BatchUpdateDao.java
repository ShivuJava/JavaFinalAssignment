package in.ineuron.main;

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import in.ineuron.util.UtilityClass;
public class BatchUpdateDao {
	
	public static void main(String[] args) {
		
		Connection connection=null;
		PreparedStatement ps=null;
		ResultSet result=null;
		String csvFilePath = "C:\\Users\\LENOVO\\Downloads";
		 int batchSize = 20;
		try {
			Scanner scan=new Scanner(System.in);
			connection = UtilityClass.getConnect();
			System.out.println("Connection established");
			connection.setAutoCommit(false);
			
			String selectQuery="insert into student (sname,sage,saddress) values (?,?,?)";
			ps = connection.prepareStatement(selectQuery);
			System.out.println("Query created");
			BufferedReader lineReader = new BufferedReader(new FileReader(csvFilePath));
			System.out.println("File data readed");
            String lineText = null;
 
            int count = 0;
 
            lineReader.readLine(); // skip header line
 
            while ((lineText = lineReader.readLine()) != null) {
            	
                String[] data = lineText.split(",");
                String sname = data[0]; 
                String sage = data[1];
                String saddress = data[2];
             
                ps.setString(1, sname);
                ps.setString(2, sage);
                ps.setString(3, saddress);
 
                ps.addBatch();
                if (count % batchSize == 0) {
                	
                    ps.executeBatch();
                }
            }
			
			int[] rows = ps.executeBatch();
		    connection.commit();
		    connection.setAutoCommit(true);
		    System.out.println("Rows Affected::"+rows.length);
			 
		}catch(Exception e){
			e.getMessage();
		}finally {
			try {
				UtilityClass.closeResources(connection, ps, result);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}

}