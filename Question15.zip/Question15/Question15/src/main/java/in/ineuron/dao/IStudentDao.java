package in.ineuron.dao;

import in.ineuron.dto.Student;

public interface IStudentDao {
	public Student searchStudent(Integer sid);
}
