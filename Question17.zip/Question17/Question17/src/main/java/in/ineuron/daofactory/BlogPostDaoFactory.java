package in.ineuron.daofactory;

import in.ineuron.dao.BlogPostImpl;
import in.ineuron.dao.IBlogPost;

public class BlogPostDaoFactory {
	private BlogPostDaoFactory() {
		
	}
	
	private static IBlogPost blogpost=null;
	public static IBlogPost getBlogPost() {
		if(blogpost==null) {
			blogpost=new BlogPostImpl();
			
		}
		return blogpost;
	}
}
