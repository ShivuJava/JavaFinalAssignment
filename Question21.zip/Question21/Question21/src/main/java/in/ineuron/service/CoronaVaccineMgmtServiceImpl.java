package in.ineuron.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ineuron.bo.CoronaVaccine;
import in.ineuron.dao.ICorornaVaccineRepo;

@Service("service")
public class CoronaVaccineMgmtServiceImpl implements ICoronaVaccineMgmtService {
	@Autowired
	private ICorornaVaccineRepo repo;
	@Override
	public String registerVaccine(CoronaVaccine vaccine) {
		CoronaVaccine saveVaccine=null;
		if(vaccine!=null) {
			saveVaccine=repo.save(vaccine);
		}
		return saveVaccine != null ? "vaccine registered succesfully with " + saveVaccine.getRegNo(): "vaccine registration failed";
	}

}
