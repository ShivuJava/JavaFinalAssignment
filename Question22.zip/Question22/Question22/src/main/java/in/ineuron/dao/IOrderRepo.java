package in.ineuron.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import in.ineuron.bo.Order;
import in.ineuron.bo.User;

public interface IOrderRepo extends CrudRepository<Order,Integer>{
	public List<Order> findByUser(User user);


}
