package in.ineuron.dao;

import org.springframework.data.repository.CrudRepository;

import in.ineuron.bo.User;

public interface IUsersRepo extends CrudRepository<User,Integer>{

}
