package in.ineuron.service;

import java.util.List;

import in.ineuron.bo.User;

public interface IUserService {
	public String saveUser(User user);
	public List<User> getUsers();
	
}
