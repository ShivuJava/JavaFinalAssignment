package in.ineuron.Exception;

public class ProductNotFoundException extends Exception{
	public ProductNotFoundException(String arg0) {
		super(arg0);
	}
}
