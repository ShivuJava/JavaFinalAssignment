package in.ineuron;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Question28Application {

	public static void main(String[] args) {
		SpringApplication.run(Question28Application.class, args);
	}

}
