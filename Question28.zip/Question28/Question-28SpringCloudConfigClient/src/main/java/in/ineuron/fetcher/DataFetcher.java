package in.ineuron.fetcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import in.ineuron.databasepropertiess.DatabaseConfig;

@Component
public class DataFetcher implements CommandLineRunner {
	
	
	@Autowired
    private  DatabaseConfig databaseConfig;


    @Override
    public void run(String... args) throws Exception {
        System.out.println("URL: " + databaseConfig.getUrl());
        System.out.println("Username: " + databaseConfig.getUsername());
        System.out.println("Password: " + databaseConfig.getPassword());
    }
}
